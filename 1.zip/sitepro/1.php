<!DOCTYPE html>
<html lang="ru">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>Главная</title>
	<base href="{{base_url}}" />
			<meta name="viewport" content="width=1200" />
		<meta name="description" content="" />
	<meta name="keywords" content="" />
	<!-- Facebook Open Graph -->
	<meta property="og:title" content="Главная" />
	<meta property="og:description" content="" />
	<meta property="og:image" content="" />
	<meta property="og:type" content="article" />
	<meta property="og:url" content="{{curr_url}}" />
	<!-- Facebook Open Graph end -->
		
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<script src="js/jquery-1.11.3.min.js" type="text/javascript"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script>
	<script src="js/main.js?v=20181222020133" type="text/javascript"></script>

	<link href="css/font-awesome/font-awesome.min.css?v=4.7.0" rel="stylesheet" type="text/css" />
	<link href="css/site.css?v=20181222020135" rel="stylesheet" type="text/css" />
	<link href="css/common.css?ts=1545586102" rel="stylesheet" type="text/css" />
	<link href="css/1.css?ts=1545586102" rel="stylesheet" type="text/css" />
	<ga-code/>
	<script type="text/javascript">
	window.useTrailingSlashes = true;
</script>
	
	<link href="css/flag-icon-css/css/flag-icon.min.css" rel="stylesheet" type="text/css" />	
	<!--[if lt IE 9]>
	<script src="js/html5shiv.min.js"></script>
	<![endif]-->

	</head>


<body><div class="root"><div class="vbox wb_container" id="wb_header">
	
<div class="wb_cont_inner"><div id="wb_element_instance0" class="wb_element wb-menu wb-menu-hidden"><ul class="hmenu"></ul><div class="clearfix"></div></div><div id="wb_element_instance1" class="wb_element wb_element_picture" title=""><img alt="gallery/fsociety-mr-robot-utiliza-herramientas_ediima20160913_0336_18" src="gallery_gen/d6f6d013d51a56e1524401262fc20046.jpg"></div><div id="wb_element_instance4" class="wb_element wb_text_element" style=" line-height: normal;"><h1 class="wb-stl-heading1">DAYZ PARADOX <span style="color:rgba(199,0,33,1);">EXILE</span></h1></div><div id="wb_element_instance5" class="wb_element wb_text_element" style=" line-height: normal;"><p class="wb-stl-custom3" style="font-family: Georgia, serif; font-size: 22px;"><i>После сдачи  ЕГЭ  У меня не хватает  баллов и денег для поступления на факультет компьютерной безопасности </i></p><p class="wb-stl-custom3" style="font-family: Georgia, serif; font-size: 22px;"><strong><i><span style="color:rgba(176,6,6,1);">Придется обеспечить работой тех кто поступил!!!</span></i></strong></p></div></div><div class="wb_cont_outer"></div><div class="wb_cont_bg"></div></div>
<div class="vbox wb_container" id="wb_main">
	
<div class="wb_cont_inner"><div id="wb_element_instance6" class="wb_element wb_text_element" style=" line-height: normal;"><h5 class="wb-stl-subtitle" style="text-align: center;">Сайт появится когда владелиц расплатиться с разработчиком</h5></div><div id="wb_element_instance7" class="wb_element wb_text_element" style=" line-height: normal;"><h2 class="wb-stl-heading2"><span style="color:rgba(173,7,15,1);">Сумма долга 3000 рублей!</span></h2></div><div id="wb_element_instance8" class="wb_element" style="width: 100%;">
			<?php
				global $show_comments;
				if (isset($show_comments) && $show_comments) {
					renderComments(1);
			?>
			<script type="text/javascript">
				$(function() {
					var block = $("#wb_element_instance8");
					var comments = block.children(".wb_comments").eq(0);
					var contentBlock = $("#wb_main");
					contentBlock.height(contentBlock.height() + comments.height());
				});
			</script>
			<?php
				} else {
			?>
			<script type="text/javascript">
				$(function() {
					$("#wb_element_instance8").hide();
				});
			</script>
			<?php
				}
			?>
			</div></div><div class="wb_cont_outer"></div><div class="wb_cont_bg"></div></div>
<div class="vbox wb_container" id="wb_footer">
	
<div class="wb_cont_inner" style="height: 234px;"><div id="wb_element_instance2" class="wb_element"><div class="wb-stl-footer">Я <i class="icon-wb-logo"></i><a href="http://sitepro.twinservers.net/" target="_blank" title="Site.pro Builder">Site.pro</a></div></div><div id="wb_element_instance3" class="wb_element wb_text_element" style=" line-height: normal;"><h1 class="wb-stl-heading1" style="font-family: Georgia, serif; font-size: 22px;"><em>Контакты Он знает</em></h1></div><div id="wb_element_instance9" class="wb_element" style="text-align: center; width: 100%;"><div class="wb_footer"></div><script type="text/javascript">
			$(function() {
				var footer = $(".wb_footer");
				var html = (footer.html() + "").replace(/^\s+|\s+$/g, "");
				if (!html) {
					footer.parent().remove();
					footer = $("#wb_footer, #wb_footer .wb_cont_inner");
					footer.css({height: ""});
				}
			});
			</script></div></div><div class="wb_cont_outer"></div><div class="wb_cont_bg"></div></div><div class="wb_sbg"></div></div>{{hr_out}}</body>
</html>
